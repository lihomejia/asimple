-- MySQL dump 10.13  Distrib 5.5.40, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: gapcompanyA008
-- ------------------------------------------------------
-- Server version	5.5.40-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_cinfo`
--

DROP TABLE IF EXISTS `t_cinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `content` text,
  `keyword` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cinfo`
--

LOCK TABLES `t_cinfo` WRITE;
/*!40000 ALTER TABLE `t_cinfo` DISABLE KEYS */;
INSERT INTO `t_cinfo` VALUES (1,NULL,0,NULL,NULL,0,0,'2015-02-03 00:41:10',1,'<p>\r\n	静宁县陇原红果品经销有限责任公司，位于中国甘肃省静宁县八里开发小区，创办于1993年，依法设有股东会、董事会等管理机构，经营范围包括：干鲜水果和蔬菜、树苗的生产、贮藏、加工、购销，林果技术咨询，纸箱、发泡网等包装材料的生产、购销。公司经过十几年的发展，现有注册资本300万元，总资产5200万元，现有员工近120人，年产值2800万元，年实现利税180万元，已成为静宁县围绕果品产、供、销，主业横跨工、农、商，能为产业提供系列化服务的果业龙头企业。公司下设三个分公司：果品分公司设有城川、仁大、治平三个购销站，拥有10000吨果品气调保鲜库一座7800米2，果品分级、清洗、打蜡、包装生产线一条，收购网络遍布全县果品产区，销售网络遍布深圳、成都、天津、兰州等大中城市，果品远销俄罗斯、哈萨克斯坦、吉尔吉斯斯坦、东南亚诸国和地区，年加工、经销果品10000吨以上，实现了果品收购、加工、冷藏、销售一条龙的规模化经营。公司已于2005年获得果品自营出口权，截止目前，年出口量达2000余吨，出口创汇突破200万美元，公司注册的“陇原红”牌苹果已成为静宁优质苹果的代名词。\r\n</p>\r\n<p>\r\n	&nbsp;&nbsp;&nbsp; 1999年，公司投资300万元创办了包装材料公司，陆续引进韩国塑料发泡网生产线一条，国产发泡网生产线五条，纸箱生产线一条，年产销“金果”牌发泡网40万包，纸箱1000万平方米，解决了果品经销中包装材料配套服务问题，服务于广大果农。2001年，设立林果科技开发公司，创建了占地1052亩的果林示范基地，基地分四区一场，即温室栽培示范区172亩（拥有温室20座），大田栽培示范区670亩，育苗区100亩、绿化花卉区100亩和牛场10亩,从业人员86人，年产优质苗木300万株，各种水果2000多吨。基地同时采取订单农业的模式，与农户签订公司包技术指导、包种苗、包销售，农户包种植用工，风险共担，利益共享的经营合同，在城川、治平、仁大等果品产区建设示范种植基地2万亩，走出了一条公司连基地，基地带农户的产业化路子。公司基地已于2005年获得国家绿A基地认证。公司一贯奉行勇拓、苦干、求质、务实的公司精神，为我县果业发展和农民增收起到了很好的带动作用，使全县果品总面积达到40万亩，果品总产量达到16万吨，总产值突破2亿元，被国家林业局授予“中国苹果之乡”和“全国经济林建设先进县”荣誉称号，并通过了ISO9001质量管理体系认证和HACCP管理体系认证，公司多次受到各级党委、政府的肯定和表彰，先后被评为“国家扶贫龙头企业”、“甘肃省扶贫龙头企业”、“甘肃省农业产业化重点龙头企业”、“甘肃省文明乡镇企业”、“甘肃省守合同重信用企业”，并被国家工商行政管理局连续评为2006、2007年度）全国“守合同重信用”单位。\r\n</p>','陇原红','泾川县陇原红果品贸易有限责任公司 简介','GSJJ'),(2,'2015-02-03 00:42:25',1,'2015-02-03 00:42:20',NULL,1,2,'2015-02-03 00:42:20',1,'主销自有基地甘肃静宁苹果，品牌为“陇原红”。','苹果','产品介绍','CPFW');
/*!40000 ALTER TABLE `t_cinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
INSERT INTO `t_dict` VALUES (1,'2015-02-03 00:45:30',1,'2015-02-03 00:45:25','品牌“陇原红”',1,2,'2015-02-03 00:45:25',1,'苹果','CPLB'),(2,'2015-03-20 06:14:27',1,'2015-03-20 06:14:15','',1,2,'2015-03-20 06:14:15',1,'人工施肥','JXLB'),(3,'2015-03-20 06:14:29',1,'2015-03-20 06:14:23','',1,2,'2015-03-20 06:14:23',1,'施肥机','JXLB'),(4,'2015-03-20 06:15:05',1,'2015-03-20 06:14:50','',1,3,'2015-03-20 06:14:50',1,'人工施肥','SYFF'),(5,'2015-03-20 06:15:08',1,'2015-03-20 06:14:59','',1,3,'2015-03-20 06:14:59',1,'穴施','SYFF'),(6,'2015-03-20 06:17:27',1,'2015-03-20 06:16:03','',1,2,'2015-03-20 06:16:03',1,'环状(轮状)施肥','SYFF'),(7,'2015-03-20 06:17:30',1,'2015-03-20 06:16:18','',1,2,'2015-03-20 06:16:18',1,'放射沟(辐射状)施肥','SYFF'),(8,'2015-03-20 06:17:34',1,'2015-03-20 06:16:33','',1,2,'2015-03-20 06:16:33',1,'全园施肥','SYFF'),(9,'2015-03-20 06:17:40',1,'2015-03-20 06:16:45','',1,2,'2015-03-20 06:16:45',1,'条沟施肥','SYFF'),(10,'2015-03-20 06:17:44',1,'2015-03-20 06:17:02','',1,2,'2015-03-20 06:17:02',1,'叶面喷施','SYFF'),(11,'2015-03-20 06:17:47',1,'2015-03-20 06:17:14','',1,2,'2015-03-20 06:17:14',1,'灌溉施肥','SYFF'),(12,'2015-03-20 06:42:22',1,'2015-03-20 06:42:18','',1,2,'2015-03-20 06:42:18',1,'人工采摘','SGFF'),(13,'2015-03-20 06:42:59',1,'2015-03-20 06:42:37','',1,2,'2015-03-20 06:42:37',1,'滴灌','GGFS'),(14,'2015-03-20 06:43:01',1,'2015-03-20 06:42:46','',1,2,'2015-03-20 06:42:46',1,'喷灌','GGFS'),(15,'2015-03-20 06:43:04',1,'2015-03-20 06:42:55','',1,2,'2015-03-20 06:42:55',1,'漫灌','GGFS'),(16,'2015-03-20 06:46:03',1,'2015-03-20 06:45:58','',1,2,'2015-03-20 06:45:58',1,'喷雾','SYFF');
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_instock`
--

DROP TABLE IF EXISTS `t_disinfectant_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_instock`
--

LOCK TABLES `t_disinfectant_instock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_outstock`
--

DROP TABLE IF EXISTS `t_disinfectant_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_outstock`
--

LOCK TABLES `t_disinfectant_outstock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_resource`
--

DROP TABLE IF EXISTS `t_disinfectant_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_resource`
--

LOCK TABLES `t_disinfectant_resource` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_stock`
--

DROP TABLE IF EXISTS `t_disinfectant_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_stock`
--

LOCK TABLES `t_disinfectant_stock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_instock`
--

DROP TABLE IF EXISTS `t_feed_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_instock`
--

LOCK TABLES `t_feed_instock` WRITE;
/*!40000 ALTER TABLE `t_feed_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_outstock`
--

DROP TABLE IF EXISTS `t_feed_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_outstock`
--

LOCK TABLES `t_feed_outstock` WRITE;
/*!40000 ALTER TABLE `t_feed_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_resource`
--

DROP TABLE IF EXISTS `t_feed_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_resource`
--

LOCK TABLES `t_feed_resource` WRITE;
/*!40000 ALTER TABLE `t_feed_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_stock`
--

DROP TABLE IF EXISTS `t_feed_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_stock`
--

LOCK TABLES `t_feed_stock` WRITE;
/*!40000 ALTER TABLE `t_feed_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_farm`
--

DROP TABLE IF EXISTS `t_grow_farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `activitydate` datetime DEFAULT NULL,
  `cell_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `persons` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `scale` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_farm`
--

LOCK TABLES `t_grow_farm` WRITE;
/*!40000 ALTER TABLE `t_grow_farm` DISABLE KEYS */;
INSERT INTO `t_grow_farm` VALUES (1,'2015-03-20 06:10:00',1,'2015-03-20 06:09:56','',1,2,'2015-03-20 06:09:56',1,'2014-03-30 00:00:00',0,'清理果园','鲍敏达',60,1,1218.00),(2,'2015-03-20 06:13:01',1,'2015-03-20 06:10:34','',1,2,'2015-03-20 06:10:34',1,'2014-04-08 00:00:00',0,'喷洒石硫合剂','鲍敏达',60,1,1218.00),(3,'2015-03-20 06:13:04',1,'2015-03-20 06:11:36','',1,2,'2015-03-20 06:11:36',1,'2014-05-12 00:00:00',0,'施用阿维灭幼脲，防止小菜蛾等','鲍敏达',60,1,1218.00),(4,'2015-03-20 06:13:07',1,'2015-03-20 06:12:25','',1,2,'2015-03-20 06:12:25',1,'2014-05-20 00:00:00',0,'施用吡虫啉，防治蚜虫等','鲍敏达',60,1,1218.00),(5,'2015-03-20 06:13:10',1,'2015-03-20 06:12:55','',1,2,'2015-03-20 06:12:55',1,'2014-06-24 00:00:00',0,'施用多菌灵，防治落叶病','鲍敏达',60,1,1218.00);
/*!40000 ALTER TABLE `t_grow_farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_harvest`
--

DROP TABLE IF EXISTS `t_grow_harvest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_harvest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `method` int(11) DEFAULT '0',
  `operatedate` datetime DEFAULT NULL,
  `product` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `respmanager` varchar(60) DEFAULT NULL,
  `scale` decimal(10,2) DEFAULT '0.00',
  `storage` varchar(60) DEFAULT NULL,
  `storemanager` varchar(60) DEFAULT NULL,
  `yield` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_harvest`
--

LOCK TABLES `t_grow_harvest` WRITE;
/*!40000 ALTER TABLE `t_grow_harvest` DISABLE KEYS */;
INSERT INTO `t_grow_harvest` VALUES (1,'2015-03-20 06:52:04',1,'2015-03-20 06:51:56','',1,2,'2015-03-20 06:51:56',1,20141011,0,12,'2014-10-11 00:00:00','苹果',1,'鲍敏达',1218.00,'公司仓库','鲍敏达',5172.00);
/*!40000 ALTER TABLE `t_grow_harvest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_irrigate`
--

DROP TABLE IF EXISTS `t_grow_irrigate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_irrigate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `cell_id` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `quantum` decimal(10,2) DEFAULT '0.00',
  `register_id` int(11) DEFAULT '0',
  `way` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_irrigate`
--

LOCK TABLES `t_grow_irrigate` WRITE;
/*!40000 ALTER TABLE `t_grow_irrigate` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_grow_irrigate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_manure`
--

DROP TABLE IF EXISTS `t_grow_manure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_manure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_manure`
--

LOCK TABLES `t_grow_manure` WRITE;
/*!40000 ALTER TABLE `t_grow_manure` DISABLE KEYS */;
INSERT INTO `t_grow_manure` VALUES (1,'2015-03-20 06:44:58',1,'2015-03-20 06:44:53',NULL,1,2,'2015-03-20 06:44:53',1,0,0.00,2,6,8,'补充营养',1,0,'鲍敏达','2014-03-21 00:00:00','60',30000.00);
/*!40000 ALTER TABLE `t_grow_manure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_pesticide`
--

DROP TABLE IF EXISTS `t_grow_pesticide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_pesticide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_pesticide`
--

LOCK TABLES `t_grow_pesticide` WRITE;
/*!40000 ALTER TABLE `t_grow_pesticide` DISABLE KEYS */;
INSERT INTO `t_grow_pesticide` VALUES (1,'2015-03-20 06:49:19',1,'2015-03-20 06:46:51',NULL,1,2,'2015-03-20 06:48:00',1,0,0.00,2,16,0,'防治白粉病',1,0,'鲍敏达','2014-04-08 00:00:00','60',100.00),(2,'2015-03-20 06:49:23',1,'2015-03-20 06:47:42',NULL,1,2,'2015-03-20 06:47:42',1,0,7.00,2,16,0,'防治小菜蛾等',1,0,'鲍敏达','2014-05-12 00:00:00','鲍敏达等',50.00),(3,'2015-03-20 06:49:27',1,'2015-03-20 06:49:13',NULL,1,2,'2015-03-20 06:49:13',1,0,7.00,2,16,0,'防治蚜虫等',1,0,'鲍敏达','2014-05-20 00:00:00','鲍敏达等',100.00),(4,'2015-03-20 06:50:32',1,'2015-03-20 06:50:23',NULL,1,2,'2015-03-20 06:50:23',1,0,10.00,2,16,0,'防治落叶病',1,0,'鲍敏达','2014-06-24 00:00:00','鲍敏达等',100.00);
/*!40000 ALTER TABLE `t_grow_pesticide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_register`
--

DROP TABLE IF EXISTS `t_grow_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `description` varchar(100) DEFAULT NULL,
  `growstatus` int(11) DEFAULT '0',
  `person` varchar(36) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qrcode` longblob,
  `regdate` datetime DEFAULT NULL,
  `reguser_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_register`
--

LOCK TABLES `t_grow_register` WRITE;
/*!40000 ALTER TABLE `t_grow_register` DISABLE KEYS */;
INSERT INTO `t_grow_register` VALUES (1,'2015-02-03 00:46:37',1,'2015-02-03 00:46:31','按照GLOBALGAP标准实施基地管理，为CIQ出口备案基地',1,2,'2015-02-03 00:46:31',1,1,'甘肃静宁“陇龙红”苹果',3,'管理员',1,'�PNG\r\n\Z\n\0\0\0\rIHDR\0\0\0�\0\0\0�\0\0\0�{��\0\0�IDATx����r�0EQ����eW�ޕ��%%���X���������!��Gw��t���z��;����]Ȩ*��B�ަ#ݦQr\"�QH!���.ŏ�~��s�^0�\n)�Э���)�6��*��B�%��<���/So�B\n)t\\(ۍgk�#��2.��s,룐B_/���~r�\n��(�eB����v�0�A��Y�R����P%j�\\�B��L+��BBiͅ#>ٟ�>��\0�RhB(�	�&�Zz�E�&`+��B�P�\\jN�5�\0��\'\n)�+�����B2��N�����B\n!B����1�[��\r\n)�+D�a�x����z�\\RH�Q!*�d]��*�P&)����B\n�\n�%C�NRG��f�\'����B\n)����z3��!j�^��B\n�B�X�5�͚7��4k~NA!����	7\Z*����?��B\n�Bs�X՞r�_/{��B\nMQgY����\";���R�ǔ�vU:��ͺ̮�RH!V�\Zk��\\��x5�j��G+��B�U�(w�s�zjE��SPH!� !�F2�\\�r�s0|���B\n�Bx���1Y�o*�\n*��B���-7UϦ�?W��_S�RhT����2U\r:Qʥ���RH�H��`�)��e�<W��RH��\n^�n�#>s�6�M�L!�b���>M/�����j[!����e.u�pXvp�/oWH!�!j�.3s�\'{�fQ�ٟRH!V��E���~L%�X��\n)�+�/��L%����Y\nU!�\Z�,l�/AY/�Q�`�RH!D����^Lz��t�_!�B�Z97�S�ew��(��B;Beͦ���^?RH�Q!<�PcTFJ���Gn�R�#��*=i�#U�<���B\n�ԗ��?~��r\\!�ꄲ�u��\\r��A</��B\nM����lEyh3���B\n)4�ߜ�nr)t����H�`�\0\0\0\0IEND�B`�','2014-08-05 00:00:00',0),(2,'2015-04-16 09:00:47',1,'2015-04-16 09:00:40','',1,2,'2015-04-16 09:00:40',1,1,'GLOBALG苹果基地',1,'王',1,NULL,'2015-04-16 00:00:00',0),(3,'2015-04-17 02:48:13',1,'2015-04-17 02:47:55','',1,2,'2015-04-17 02:47:55',1,2,'G',1,'E',1,NULL,'2015-04-17 00:00:00',0),(4,NULL,0,'2015-04-17 02:47:58','',1,0,'2015-04-17 02:47:58',1,2,'G',1,'E',1,NULL,'2015-04-17 00:00:00',0);
/*!40000 ALTER TABLE `t_grow_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_resource`
--

DROP TABLE IF EXISTS `t_grow_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_resource`
--

LOCK TABLES `t_grow_resource` WRITE;
/*!40000 ALTER TABLE `t_grow_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_grow_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_instock`
--

DROP TABLE IF EXISTS `t_manure_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_instock`
--

LOCK TABLES `t_manure_instock` WRITE;
/*!40000 ALTER TABLE `t_manure_instock` DISABLE KEYS */;
INSERT INTO `t_manure_instock` VALUES (1,NULL,0,'2015-03-20 03:01:07','',1,2,'2015-03-20 03:01:07',1,7,1,8,6,30000.00,5,'','2015-03-31 00:00:00','2014-04-01 00:00:00',1,'',1,'','');
/*!40000 ALTER TABLE `t_manure_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_outstock`
--

DROP TABLE IF EXISTS `t_manure_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_outstock`
--

LOCK TABLES `t_manure_outstock` WRITE;
/*!40000 ALTER TABLE `t_manure_outstock` DISABLE KEYS */;
INSERT INTO `t_manure_outstock` VALUES (1,'2015-03-20 03:05:14',1,'2015-03-20 03:05:09','',0,2,NULL,0,7,0,8,6,30000.00,5,1,'2015-04-01 00:00:00',1,1,1);
/*!40000 ALTER TABLE `t_manure_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_resource`
--

DROP TABLE IF EXISTS `t_manure_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_resource`
--

LOCK TABLES `t_manure_resource` WRITE;
/*!40000 ALTER TABLE `t_manure_resource` DISABLE KEYS */;
INSERT INTO `t_manure_resource` VALUES (1,'2015-03-20 02:41:33',1,'2015-03-20 02:35:55','',1,2,'2015-03-20 02:35:55',1,'有机肥','ZL'),(2,'2015-03-20 02:41:36',1,'2015-03-20 02:36:06','',1,2,'2015-03-20 02:36:06',1,'氮肥','ZL'),(3,'2015-03-20 02:41:39',1,'2015-03-20 02:41:28','',1,2,'2015-03-20 02:41:28',1,'复合肥','ZL'),(4,'2015-03-20 02:42:51',1,'2015-03-20 02:42:15','大三元复合肥',1,3,'2015-03-20 02:42:15',1,'三门峡龙飞公司','SCS'),(5,'2015-03-20 02:44:12',1,'2015-03-20 02:44:08','',1,2,'2015-03-20 02:44:08',1,'50kg/袋','GG'),(6,'2015-03-20 02:45:36',1,'2015-03-20 02:45:31','',1,2,'2015-03-20 02:45:31',1,'三门峡龙飞生物工程有限公司','SCS'),(7,'2015-03-20 02:59:59',1,'2015-03-20 02:59:11','登记注册号',1,2,'2015-03-20 02:59:11',1,'农肥（2013）准字3308号','SCPH'),(8,'2015-03-20 02:59:49',1,'2015-03-20 02:59:37','',1,2,'2015-03-20 02:59:37',1,'有机肥','PM'),(9,'2015-03-20 02:59:53',1,'2015-03-20 02:59:45','',1,2,'2015-03-20 02:59:45',1,'复合肥','PM');
/*!40000 ALTER TABLE `t_manure_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_stock`
--

DROP TABLE IF EXISTS `t_manure_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_stock`
--

LOCK TABLES `t_manure_stock` WRITE;
/*!40000 ALTER TABLE `t_manure_stock` DISABLE KEYS */;
INSERT INTO `t_manure_stock` VALUES (1,NULL,0,'2015-03-20 03:01:15',NULL,0,0,NULL,0,7,0,8,6,0.00,5);
/*!40000 ALTER TABLE `t_manure_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_instock`
--

DROP TABLE IF EXISTS `t_medicine_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_instock`
--

LOCK TABLES `t_medicine_instock` WRITE;
/*!40000 ALTER TABLE `t_medicine_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_outstock`
--

DROP TABLE IF EXISTS `t_medicine_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_outstock`
--

LOCK TABLES `t_medicine_outstock` WRITE;
/*!40000 ALTER TABLE `t_medicine_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_resource`
--

DROP TABLE IF EXISTS `t_medicine_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_resource`
--

LOCK TABLES `t_medicine_resource` WRITE;
/*!40000 ALTER TABLE `t_medicine_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_stock`
--

DROP TABLE IF EXISTS `t_medicine_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_stock`
--

LOCK TABLES `t_medicine_stock` WRITE;
/*!40000 ALTER TABLE `t_medicine_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_farm`
--

DROP TABLE IF EXISTS `t_nurture_farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `activitydate` datetime DEFAULT NULL,
  `cell_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `persons` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `scale` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_farm`
--

LOCK TABLES `t_nurture_farm` WRITE;
/*!40000 ALTER TABLE `t_nurture_farm` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_harvest`
--

DROP TABLE IF EXISTS `t_nurture_harvest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_harvest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `method` varchar(60) DEFAULT NULL,
  `operatedate` datetime DEFAULT NULL,
  `product` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `respmanager` varchar(60) DEFAULT NULL,
  `scale` decimal(10,2) DEFAULT '0.00',
  `storage` varchar(60) DEFAULT NULL,
  `storemanager` varchar(60) DEFAULT NULL,
  `yield` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_harvest`
--

LOCK TABLES `t_nurture_harvest` WRITE;
/*!40000 ALTER TABLE `t_nurture_harvest` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_harvest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_irrigate`
--

DROP TABLE IF EXISTS `t_nurture_irrigate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_irrigate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `cell_id` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `quantum` decimal(10,2) DEFAULT '0.00',
  `register_id` int(11) DEFAULT '0',
  `way` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_irrigate`
--

LOCK TABLES `t_nurture_irrigate` WRITE;
/*!40000 ALTER TABLE `t_nurture_irrigate` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_irrigate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_manure`
--

DROP TABLE IF EXISTS `t_nurture_manure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_manure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_manure`
--

LOCK TABLES `t_nurture_manure` WRITE;
/*!40000 ALTER TABLE `t_nurture_manure` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_manure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_pesticide`
--

DROP TABLE IF EXISTS `t_nurture_pesticide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_pesticide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_pesticide`
--

LOCK TABLES `t_nurture_pesticide` WRITE;
/*!40000 ALTER TABLE `t_nurture_pesticide` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_pesticide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_register`
--

DROP TABLE IF EXISTS `t_nurture_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `description` varchar(100) DEFAULT NULL,
  `nurturestatus` int(11) DEFAULT '0',
  `person` varchar(36) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qrcode` longblob,
  `regdate` datetime DEFAULT NULL,
  `reguser_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_register`
--

LOCK TABLES `t_nurture_register` WRITE;
/*!40000 ALTER TABLE `t_nurture_register` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_instock`
--

DROP TABLE IF EXISTS `t_pesticide_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_instock`
--

LOCK TABLES `t_pesticide_instock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_instock` DISABLE KEYS */;
INSERT INTO `t_pesticide_instock` VALUES (1,NULL,0,'2015-03-20 06:01:06','',1,2,'2015-03-20 06:01:06',1,7,1,12,3,100.00,11,'','2014-12-31 00:00:00','2014-04-02 00:00:00',1,'',1,'',''),(2,NULL,0,'2015-03-20 06:02:07','',1,2,'2015-03-20 06:02:07',1,8,1,13,4,200.00,11,'','2015-03-31 00:00:00','2014-03-31 00:00:00',1,'',2,'',''),(3,NULL,0,'2015-03-20 06:03:07','',1,2,'2015-03-20 06:03:07',1,9,2,14,5,400.00,11,'','2015-03-31 00:00:00','2014-04-01 00:00:00',1,'',3,'',''),(4,NULL,0,'2015-03-20 06:03:51','',1,2,'2015-03-20 06:03:51',1,10,2,15,6,300.00,11,'','2015-01-01 00:00:00','2014-05-14 00:00:00',1,'',4,'','');
/*!40000 ALTER TABLE `t_pesticide_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_outstock`
--

DROP TABLE IF EXISTS `t_pesticide_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_outstock`
--

LOCK TABLES `t_pesticide_outstock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_outstock` DISABLE KEYS */;
INSERT INTO `t_pesticide_outstock` VALUES (1,'2015-03-20 06:06:32',1,'2015-03-20 06:05:05','',0,2,NULL,0,7,0,12,3,50.00,11,1,'2014-05-12 00:00:00',1,1,1),(2,'2015-03-20 06:06:35',1,'2015-03-20 06:05:33','',0,2,NULL,0,8,0,13,4,45.00,11,1,'2014-05-20 00:00:00',1,1,2),(3,'2015-03-20 06:06:38',1,'2015-03-20 06:05:59','',0,2,NULL,0,9,0,14,5,300.00,11,1,'2014-04-08 00:00:00',1,1,3),(4,'2015-03-20 06:06:41',1,'2015-03-20 06:06:25','',0,2,NULL,0,10,0,15,6,55.00,11,1,'2014-06-24 00:00:00',1,1,4);
/*!40000 ALTER TABLE `t_pesticide_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_resource`
--

DROP TABLE IF EXISTS `t_pesticide_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_resource`
--

LOCK TABLES `t_pesticide_resource` WRITE;
/*!40000 ALTER TABLE `t_pesticide_resource` DISABLE KEYS */;
INSERT INTO `t_pesticide_resource` VALUES (1,'2015-03-20 03:06:20',1,'2015-03-20 03:05:48','',1,2,'2015-03-20 03:05:48',1,'杀虫剂','ZL'),(2,'2015-03-20 03:06:24',1,'2015-03-20 03:06:01','',1,2,'2015-03-20 03:06:01',1,'杀菌剂','ZL'),(3,'2015-03-20 03:07:34',1,'2015-03-20 03:06:47','',1,2,'2015-03-20 03:06:47',1,'安全全丰生物科技有限公司','SCS'),(4,'2015-03-20 03:07:37',1,'2015-03-20 03:07:03','',1,2,'2015-03-20 03:07:03',1,'江苏龙灯化学有限公司','SCS'),(5,'2015-03-20 03:07:40',1,'2015-03-20 03:07:14','',1,2,'2015-03-20 03:07:14',1,'湖北太极生化有限公司','SCS'),(6,'2015-03-20 03:07:44',1,'2015-03-20 03:07:30','',1,2,'2015-03-20 03:07:30',1,'济南绿霸农药有限公司','SCS'),(7,'2015-03-20 03:15:18',1,'2015-03-20 03:13:33','农药登记证号',1,2,'2015-03-20 03:13:33',1,'PD20092808','SCPH'),(8,'2015-03-20 03:15:20',1,'2015-03-20 03:13:49','农药登记证号',1,2,'2015-03-20 03:13:49',1,'PD20101225','SCPH'),(9,'2015-03-20 03:15:24',1,'2015-03-20 03:14:06','农药登记证号',1,2,'2015-03-20 03:14:06',1,'PD20085408','SCPH'),(10,'2015-03-20 03:15:26',1,'2015-03-20 03:15:14','',1,2,'2015-03-20 03:15:14',1,'PD20070613','SCPH'),(11,'2015-03-20 05:57:49',1,'2015-03-20 05:57:45','',1,2,'2015-03-20 05:57:45',1,'500mL/瓶','GG'),(12,'2015-03-20 05:58:49',1,'2015-03-20 05:58:09','',1,2,'2015-03-20 05:58:09',1,'阿维灭幼尿','PM'),(13,'2015-03-20 05:58:52',1,'2015-03-20 05:58:19','',1,2,'2015-03-20 05:58:19',1,'吡虫啉','PM'),(14,'2015-03-20 05:58:55',1,'2015-03-20 05:58:30','',1,2,'2015-03-20 05:58:30',1,'石硫合剂','PM'),(15,'2015-03-20 05:58:58',1,'2015-03-20 05:58:43','',1,2,'2015-03-20 05:58:43',1,'多菌灵','PM');
/*!40000 ALTER TABLE `t_pesticide_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_stock`
--

DROP TABLE IF EXISTS `t_pesticide_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_stock`
--

LOCK TABLES `t_pesticide_stock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_stock` DISABLE KEYS */;
INSERT INTO `t_pesticide_stock` VALUES (1,NULL,0,'2015-03-20 06:01:18',NULL,0,0,NULL,0,7,0,12,3,50.00,11),(2,NULL,0,'2015-03-20 06:02:13',NULL,0,0,NULL,0,8,0,13,4,155.00,11),(3,NULL,0,'2015-03-20 06:03:55',NULL,0,0,NULL,0,9,0,14,5,100.00,11),(4,NULL,0,'2015-03-20 06:03:59',NULL,0,0,NULL,0,10,0,15,6,245.00,11);
/*!40000 ALTER TABLE `t_pesticide_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_cell`
--

DROP TABLE IF EXISTS `t_production_cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_production_cell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `builddate` datetime DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `usestatus` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_cell`
--

LOCK TABLES `t_production_cell` WRITE;
/*!40000 ALTER TABLE `t_production_cell` DISABLE KEYS */;
INSERT INTO `t_production_cell` VALUES (1,'2015-02-03 00:44:37',1,'2015-02-03 00:44:32',NULL,1,2,'2015-04-16 09:00:40',1,1218.00,'2014-08-05 00:00:00','GSLYH01','泾川县窑店镇将军村',1),(2,'2015-04-17 02:46:53',1,'2015-04-16 09:01:17',NULL,1,2,'2015-04-17 02:47:58',1,1000.00,'2015-04-16 00:00:00','GSLYH02','**村',1);
/*!40000 ALTER TABLE `t_production_cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sale`
--

DROP TABLE IF EXISTS `t_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `contact` varchar(50) DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `partner` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `saledate` datetime DEFAULT NULL,
  `spec` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sale`
--

LOCK TABLES `t_sale` WRITE;
/*!40000 ALTER TABLE `t_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_transport`
--

DROP TABLE IF EXISTS `t_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `contact` varchar(50) DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `partner` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `transportdate` datetime DEFAULT NULL,
  `spec` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_transport`
--

LOCK TABLES `t_transport` WRITE;
/*!40000 ALTER TABLE `t_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `pass_word` varchar(20) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,NULL,0,NULL,NULL,0,0,'2015-02-03 00:42:59',1,'GSLYH','GSLYH','公司管理员');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-17 11:13:42
