-- MySQL dump 10.13  Distrib 5.5.40, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: gap
-- ------------------------------------------------------
-- Server version	5.5.40-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_company`
--

DROP TABLE IF EXISTS `t_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `companyname` varchar(60) DEFAULT NULL,
  `companyno` varchar(60) DEFAULT NULL,
  `innercode` varchar(60) DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_company`
--

LOCK TABLES `t_company` WRITE;
/*!40000 ALTER TABLE `t_company` DISABLE KEYS */;
INSERT INTO `t_company` VALUES (4,'2014-10-14 14:37:01',1,'2014-10-14 14:36:57',NULL,0,3,NULL,0,'种植公司','ZZ','A004',NULL,1),(5,'2014-10-14 14:37:14',1,'2014-10-14 14:37:11',NULL,0,2,NULL,0,'养殖公司','YZ','A005',NULL,2),(6,'2014-12-01 07:38:16',1,'2014-12-01 07:38:09',NULL,0,2,NULL,0,'中认环宇','ER','A006',NULL,1),(7,'2015-01-26 08:01:42',1,'2015-01-26 08:01:35',NULL,0,2,NULL,0,'静宁常津果品有限责任公司','GSJN01','A007',NULL,1),(8,'2015-02-03 00:39:45',1,'2015-02-03 00:39:14',NULL,0,2,NULL,0,'泾川县陇原红果品贸易有限责任公司','GSLYH','A008',NULL,1);
/*!40000 ALTER TABLE `t_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_info`
--

DROP TABLE IF EXISTS `t_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `content` text,
  `keyword` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_info`
--

LOCK TABLES `t_info` WRITE;
/*!40000 ALTER TABLE `t_info` DISABLE KEYS */;
INSERT INTO `t_info` VALUES (1,'2014-12-01 09:33:54',1,'2013-05-15 00:44:01','GGagag',0,2,'<p style=\"color:#555B6E;text-indent:0px;font-family:Arial;font-size:12px;font-style:normal;font-weight:normal;background-color:#FFFFFF;\" class=\"MsoNormal\">\r\n	oIframe的更多的属性参考表10.2，引自CSDN论坛。\r\n</p>\r\n<p style=\"color:#555B6E;text-indent:0px;font-family:Arial;font-size:12px;font-style:normal;font-weight:normal;background-color:#FFFFFF;\" class=\"af\">\r\n	o表10.2 Iframe属性参考值\r\n</p>\r\n<table style=\"border-collapse:collapse;\" class=\"MsoNormalTable\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\r\n	o\r\n	<tbody>\r\n		o\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p class=\"af2\">\r\n					o属 &nbsp;&nbsp; 性\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p class=\"af2\">\r\n					o说&nbsp;&nbsp;&nbsp; 明\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					onRight\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的右边距宽度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					omargin-top marginTop\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的上边距宽度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					ooverflow-x overflowX\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取当内容超出对象宽度时如何管理对象内容\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					ooverflow-y overflowY\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取当内容超出对象高度时如何管理对象内容\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelBottom\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的下方位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelHeight\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的高度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelLeft\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的左侧位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelRight\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的右侧位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelTop\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的上方位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					opixelWidth\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的宽度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposBottom\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以bottom标签属性指定的单位的对象下方位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposHeight\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以height标签属性指定的单位的对象高度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposition position\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象所使用的定位方式\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposLeft\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以left标签属性指定的单位的对象左侧位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n	</tbody>\r\n</table>\r\n<p style=\"color:#000000;text-indent:0px;font-family:微软雅黑;font-size:18px;font-style:normal;font-weight:normal;\" align=\"right\">\r\n	o\r\n</p>\r\n<p style=\"color:#000000;text-indent:0px;font-family:微软雅黑;font-size:18px;font-style:normal;font-weight:normal;\" align=\"right\">\r\n	o\r\n</p>\r\n<table style=\"border-collapse:collapse;\" class=\"MsoNormalTable\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">\r\n	o\r\n	<tbody>\r\n		o\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p class=\"af2\">\r\n					o属&nbsp;&nbsp;&nbsp; 性\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p class=\"af2\">\r\n					o说&nbsp;&nbsp;&nbsp; 明\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposRight\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以right标签属性指定的单位的对象右侧位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposTop\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以top标签属性指定的单位的对象上方位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oposWidth\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取以width标签属性指定的单位的对象宽度\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oright right\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象相对于文档层次中下个已定位对象的右边界的位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					ofloat styleFloat\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取文本要绕排到对象的哪一侧\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					otext-autospace textAutospace\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取自动留空和文本的窄空间宽度调整\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					otop top\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象相对于文档层次中下个定位对象的上边界的位置\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					ovisibility visibility\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的内容是否显示\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					oz-index z-index\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取定位对象的堆叠次序\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n		<tr>\r\n			o\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"179\">\r\n				o\r\n				<p style=\"text-indent:7.2pt;\" class=\"ae\">\r\n					ozoom zoom\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n			<td style=\"font-size:12px;\" valign=\"top\" width=\"440\">\r\n				o\r\n				<p style=\"text-indent:29.6pt;\" class=\"ae\">\r\n					o设置或获取对象的放大比例\r\no\r\n				</p>\r\no\r\n			</td>\r\no\r\n		</tr>\r\no\r\n	</tbody>\r\n</table>\r\n<p>\r\n	o\r\n</p>','关于2013年春节放假安排的...','关于2013年春节放假安排的...','TZGG','2014-12-01 09:33:46',1),(2,'2014-12-01 09:33:56',1,'2013-05-15 23:04:52',NULL,0,2,'关于2013年春节期间证书邮...','关于2013年春节期间证书邮...','关于2013年春节期间证书邮...','TZGG',NULL,0),(3,'2014-12-01 09:33:59',1,'2013-05-15 23:05:03',NULL,0,2,'财政部 发展改革委关于调整...','财政部 发展改革委关于调整...','财政部 发展改革委关于调整...','TZGG',NULL,0),(4,NULL,0,'2013-05-15 23:05:13',NULL,0,0,'2013年有机产品认证获证企...','2013年有机产品认证获证企...','2013年有机产品认证获证企...','TZGG',NULL,0),(5,NULL,0,'2013-05-15 23:05:21',NULL,0,0,'良好农业规范认证获证企业...','良好农业规范认证获证企业...','良好农业规范认证获证企业...','TZGG',NULL,0),(6,NULL,0,'2013-05-15 23:05:31',NULL,0,0,'信息安全管理体系认证获证...','信息安全管理体系认证获证...','信息安全管理体系认证获证...','TZGG',NULL,0),(7,NULL,0,'2013-05-15 23:05:43',NULL,0,0,'关于2004年和2009年获证...','关于2004年和2009年获证...','关于2004年和2009年获证...','TZGG',NULL,0),(8,NULL,0,'2013-05-15 23:07:27',NULL,0,0,'中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','QYXXH',NULL,0),(9,NULL,0,'2013-05-15 23:07:38',NULL,0,0,'中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','QYXXH',NULL,0),(10,NULL,0,'2013-05-15 23:07:46',NULL,0,0,'广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','QYXXH',NULL,0),(11,NULL,0,'2013-05-15 23:07:54',NULL,0,0,'王克娇主任到广州调研工作','王克娇主任到广州调研工作','王克娇主任到广州调研工作','QYXXH',NULL,0),(12,NULL,0,'2013-05-15 23:08:04',NULL,0,0,'中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','QYXXH',NULL,0),(13,NULL,0,'2013-05-15 23:08:14',NULL,0,0,'中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','QYXXH',NULL,0),(14,NULL,0,'2013-05-15 23:08:25',NULL,0,0,'中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','QYXXH',NULL,0),(15,NULL,0,'2013-05-15 23:08:35',NULL,0,0,'中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','QYXXH',NULL,0),(16,NULL,0,'2013-05-15 23:08:47',NULL,0,0,'<h2>\r\no中心与天祥公证行有限公司签订CCC认...\r\n</h2>','中心与天祥公证行有限公司签订CCC认...','中心与天祥公证行有限公司签订CCC认...','QYXXH',NULL,0),(17,NULL,0,'2013-05-15 23:08:56',NULL,0,0,'广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','QYXXH',NULL,0),(18,NULL,0,'2013-05-15 23:09:04',NULL,0,0,'王克娇主任到广州调研工作','王克娇主任到广州调研工作','王克娇主任到广州调研工作','QYXXH',NULL,0),(19,NULL,0,'2013-05-15 23:09:13',NULL,0,0,'中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','QYXXH',NULL,0),(20,NULL,0,'2013-05-15 23:09:24',NULL,0,0,'中心派员参加IQnet亚洲成员机构会..','中心派员参加IQnet亚洲成员机构会..','中心派员参加IQnet亚洲成员机构会..','QYXXH',NULL,0),(21,NULL,0,'2013-05-15 23:09:35',NULL,0,0,'中心与天祥公证行有限公司签订CCC认...','中心与天祥公证行有限公司签订CCC认...','中心与天祥公证行有限公司签订CCC认...','QYXXH',NULL,0),(22,NULL,0,'2013-05-15 23:09:50',NULL,0,0,'中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','中心与天祥公证行有限公司签订CCC认..','QYXXH',NULL,0),(23,NULL,0,'2013-05-15 23:10:02',NULL,0,0,'广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','广州分中心低碳工作获得广东省发改委认...','QYXXH',NULL,0),(24,NULL,0,'2013-05-15 23:10:15',NULL,0,0,'王克娇主任到广州调研工作','王克娇主任到广州调研工作','王克娇主任到广州调研工作','QYXXH',NULL,0),(25,NULL,0,'2013-05-15 23:10:27',NULL,0,0,'中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','中心积极做好节能产品惠民工程相关工作','QYXXH',NULL,0),(26,NULL,0,'2013-05-15 23:10:36',NULL,0,0,'中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','中心派员参加IQnet亚洲成员机构会...','QYXXH',NULL,0),(27,NULL,0,'2013-05-15 23:10:45',NULL,0,0,'中心与天祥公证行有限公司签订CCC认...','中心与天祥公证行有限公司签订CCC认...','中心与天祥公证行有限公司签订CCC认...','QYXXH',NULL,0),(28,NULL,0,'2013-05-15 23:10:59',NULL,0,0,'关于2013年春节放假安排年春节放假安...','关于2013年春节放假安排年春节放假安...','关于2013年春节放假安排年春节放假安...','QYXW',NULL,0),(29,NULL,0,'2013-05-15 23:11:13',NULL,0,0,'关于2013年春节期间证书邮...','关于2013年春节期间证书邮...','关于2013年春节期间证书邮...','QYXW',NULL,0),(30,NULL,0,'2013-05-15 23:11:22',NULL,0,0,'财政部 发展改革委关于调整..','财政部 发展改革委关于调整..','财政部 发展改革委关于调整..','QYXW',NULL,0),(31,NULL,0,'2013-05-15 23:11:34',NULL,0,0,'2013年有机产品认证获证企...','2013年有机产品认证获证企...','2013年有机产品认证获证企...','QYXW',NULL,0),(32,NULL,0,'2013-05-15 23:11:42',NULL,0,0,'良好农业规范认证获证企业...','良好农业规范认证获证企业...','良好农业规范认证获证企业...','QYXW',NULL,0),(33,NULL,0,'2013-05-15 23:11:51',NULL,0,0,'信息安全管理体系认证获证..','信息安全管理体系认证获证..','信息安全管理体系认证获证..','QYXW',NULL,0),(34,NULL,0,'2013-05-15 23:12:00',NULL,0,0,'关于2013年春节放假安排的...','关于2013年春节放假安排的...','关于2013年春节放假安排的...','QYXW',NULL,0);
/*!40000 ALTER TABLE `t_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `pass_word` varchar(20) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,NULL,0,'2013-06-06 20:22:39',NULL,0,0,'2013-06-06 20:22:39',0,'admin','admin','超级管理员');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-17 11:11:52
