-- MySQL dump 10.13  Distrib 5.5.40, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: gapcompanyA005
-- ------------------------------------------------------
-- Server version	5.5.40-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_cinfo`
--

DROP TABLE IF EXISTS `t_cinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_cinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `content` text,
  `keyword` varchar(250) DEFAULT NULL,
  `title` varchar(250) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_cinfo`
--

LOCK TABLES `t_cinfo` WRITE;
/*!40000 ALTER TABLE `t_cinfo` DISABLE KEYS */;
INSERT INTO `t_cinfo` VALUES (1,NULL,0,NULL,NULL,0,0,NULL,0,NULL,NULL,NULL,'GSJJ');
/*!40000 ALTER TABLE `t_cinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_dict`
--

DROP TABLE IF EXISTS `t_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_dict`
--

LOCK TABLES `t_dict` WRITE;
/*!40000 ALTER TABLE `t_dict` DISABLE KEYS */;
INSERT INTO `t_dict` VALUES (1,NULL,0,'2013-06-06 20:40:48','',3,0,'2013-06-06 20:40:48',3,'水稻A','CPLB'),(2,NULL,0,'2013-06-06 20:40:57','',3,0,'2013-06-06 20:40:57',3,'水稻B','CPLB'),(3,NULL,0,'2013-06-06 20:41:03','',3,0,'2013-06-06 20:41:03',3,'玉米A','CPLB'),(4,NULL,0,'2013-06-06 20:41:09','',3,0,'2013-06-06 20:41:09',3,'玉米B','CPLB'),(5,NULL,0,'2013-06-06 20:41:15','',3,0,'2013-06-06 20:41:15',3,'小麦A','CPLB'),(6,NULL,0,'2013-06-06 20:41:20','',3,0,'2013-06-06 20:41:20',3,'小麦B','CPLB'),(7,NULL,0,'2013-06-06 20:41:26','',3,0,'2013-06-06 20:41:26',3,'高粱A','CPLB'),(8,NULL,0,'2013-06-06 20:41:31','',3,0,'2013-06-06 20:41:31',3,'高粱B','CPLB'),(9,NULL,0,'2013-06-06 20:41:49','',3,0,'2013-06-06 20:41:49',3,'插秧机','JXLB'),(10,NULL,0,'2013-06-06 20:41:56','',3,0,'2013-06-06 20:41:56',3,'收割机','JXLB'),(11,NULL,0,'2013-06-06 20:42:05','',3,0,'2013-06-06 20:42:05',3,'播种机','JXLB'),(15,NULL,0,'2013-06-06 20:42:56','',3,0,'2013-06-06 20:42:56',3,'纯人工','SGFF'),(16,NULL,0,'2013-06-06 20:43:04','',3,0,'2013-06-06 20:43:04',3,'半自动化','SGFF'),(17,NULL,0,'2013-06-06 20:43:12','',3,0,'2013-06-06 20:43:12',3,'全自动化','SGFF'),(18,NULL,0,'2013-06-06 20:48:51','',3,0,'2013-06-06 20:48:51',3,'方法1','SYFF'),(19,NULL,0,'2013-06-06 20:48:57','',3,0,'2013-06-06 20:48:57',3,'方法2','SYFF'),(20,NULL,0,'2013-06-06 20:49:05','',3,0,'2013-06-06 20:49:05',3,'局部','GGFS'),(21,NULL,0,'2013-06-06 20:49:16','',3,0,'2013-06-06 20:49:16',3,'全','GGFS'),(22,'2013-08-29 08:44:26',2,'2013-08-29 08:44:20','',2,2,'2013-08-29 08:44:20',2,'茶叶A','CPLB');
/*!40000 ALTER TABLE `t_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_instock`
--

DROP TABLE IF EXISTS `t_disinfectant_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_instock`
--

LOCK TABLES `t_disinfectant_instock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_outstock`
--

DROP TABLE IF EXISTS `t_disinfectant_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_outstock`
--

LOCK TABLES `t_disinfectant_outstock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_resource`
--

DROP TABLE IF EXISTS `t_disinfectant_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_resource`
--

LOCK TABLES `t_disinfectant_resource` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_disinfectant_stock`
--

DROP TABLE IF EXISTS `t_disinfectant_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_disinfectant_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_disinfectant_stock`
--

LOCK TABLES `t_disinfectant_stock` WRITE;
/*!40000 ALTER TABLE `t_disinfectant_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_disinfectant_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_instock`
--

DROP TABLE IF EXISTS `t_feed_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_instock`
--

LOCK TABLES `t_feed_instock` WRITE;
/*!40000 ALTER TABLE `t_feed_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_outstock`
--

DROP TABLE IF EXISTS `t_feed_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_outstock`
--

LOCK TABLES `t_feed_outstock` WRITE;
/*!40000 ALTER TABLE `t_feed_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_resource`
--

DROP TABLE IF EXISTS `t_feed_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_resource`
--

LOCK TABLES `t_feed_resource` WRITE;
/*!40000 ALTER TABLE `t_feed_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_feed_stock`
--

DROP TABLE IF EXISTS `t_feed_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_feed_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_feed_stock`
--

LOCK TABLES `t_feed_stock` WRITE;
/*!40000 ALTER TABLE `t_feed_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_feed_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_farm`
--

DROP TABLE IF EXISTS `t_grow_farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `activitydate` datetime DEFAULT NULL,
  `cell_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `persons` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `scale` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_farm`
--

LOCK TABLES `t_grow_farm` WRITE;
/*!40000 ALTER TABLE `t_grow_farm` DISABLE KEYS */;
INSERT INTO `t_grow_farm` VALUES (1,NULL,0,'2013-06-06 20:54:28','',3,0,'2013-06-06 20:54:42',3,'2013-06-02 00:00:00',0,'除草','张经理',1,1,1.00),(2,NULL,0,'2013-06-06 20:55:06','',3,0,'2013-06-06 20:55:06',3,'2013-06-02 00:00:00',0,'施肥','GJIA',2,1,2.00),(3,'2013-08-29 06:41:38',2,'2013-08-29 06:41:33','机械播种，1天完成',2,2,'2013-08-29 06:41:33',2,'2013-08-29 00:00:00',0,'播种','王**',20,4,500.00),(4,NULL,0,'2013-08-29 06:41:58','',2,0,'2013-08-29 06:41:58',2,'2013-08-30 00:00:00',0,'灌溉','王',3,4,500.00),(5,NULL,0,'2013-08-29 06:42:20','',2,0,'2013-08-29 06:42:20',2,'2013-09-12 00:00:00',0,'除草','王',20,4,500.00);
/*!40000 ALTER TABLE `t_grow_farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_harvest`
--

DROP TABLE IF EXISTS `t_grow_harvest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_harvest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `method` int(11) DEFAULT '0',
  `operatedate` datetime DEFAULT NULL,
  `product` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `respmanager` varchar(60) DEFAULT NULL,
  `scale` decimal(10,2) DEFAULT '0.00',
  `storage` varchar(60) DEFAULT NULL,
  `storemanager` varchar(60) DEFAULT NULL,
  `yield` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_harvest`
--

LOCK TABLES `t_grow_harvest` WRITE;
/*!40000 ALTER TABLE `t_grow_harvest` DISABLE KEYS */;
INSERT INTO `t_grow_harvest` VALUES (1,'2013-08-29 07:00:17',2,'2013-08-29 07:00:10','',2,2,'2013-08-29 07:00:10',2,20130830,0,15,'2013-08-30 00:00:00','甜玉米',4,'王',500.00,'A仓库','李',25.00),(2,NULL,0,'2013-08-29 07:00:47','',2,0,'2013-08-29 07:00:47',2,20130831,0,16,'2013-08-31 00:00:00','甜玉米',4,'B',100.00,'B','C',5.00);
/*!40000 ALTER TABLE `t_grow_harvest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_irrigate`
--

DROP TABLE IF EXISTS `t_grow_irrigate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_irrigate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `cell_id` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `quantum` decimal(10,2) DEFAULT '0.00',
  `register_id` int(11) DEFAULT '0',
  `way` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_irrigate`
--

LOCK TABLES `t_grow_irrigate` WRITE;
/*!40000 ALTER TABLE `t_grow_irrigate` DISABLE KEYS */;
INSERT INTO `t_grow_irrigate` VALUES (1,NULL,0,'2013-06-06 20:55:34','',3,0,'2013-06-06 20:55:34',3,23.00,0,'2013-05-27 00:00:00','ag',2.00,1,20);
/*!40000 ALTER TABLE `t_grow_irrigate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_manure`
--

DROP TABLE IF EXISTS `t_grow_manure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_manure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_manure`
--

LOCK TABLES `t_grow_manure` WRITE;
/*!40000 ALTER TABLE `t_grow_manure` DISABLE KEYS */;
INSERT INTO `t_grow_manure` VALUES (1,NULL,0,'2013-06-06 20:55:54',NULL,3,0,'2013-06-06 20:55:54',3,0,1.00,9,18,1,'2ag',1,0,'gn','2013-06-04 00:00:00','ag',23.00),(2,'2013-08-29 06:43:33',2,'2013-08-29 06:43:28',NULL,2,2,'2013-08-29 06:43:28',2,0,0.00,11,18,1,'基肥',4,0,'李','2013-08-29 00:00:00','王',500.00),(3,NULL,0,'2013-08-29 06:44:01',NULL,2,0,'2013-08-29 06:44:01',2,0,0.00,9,19,20,'提供营养',4,0,'李','2013-08-30 00:00:00','王',200.00);
/*!40000 ALTER TABLE `t_grow_manure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_pesticide`
--

DROP TABLE IF EXISTS `t_grow_pesticide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_pesticide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_pesticide`
--

LOCK TABLES `t_grow_pesticide` WRITE;
/*!40000 ALTER TABLE `t_grow_pesticide` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_grow_pesticide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_register`
--

DROP TABLE IF EXISTS `t_grow_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `description` varchar(100) DEFAULT NULL,
  `growstatus` int(11) DEFAULT '0',
  `person` varchar(36) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qrcode` longblob,
  `regdate` datetime DEFAULT NULL,
  `reguser_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_register`
--

LOCK TABLES `t_grow_register` WRITE;
/*!40000 ALTER TABLE `t_grow_register` DISABLE KEYS */;
INSERT INTO `t_grow_register` VALUES (1,'2013-06-06 20:53:42',3,'2013-06-06 20:51:26','早稻',3,2,'2013-06-06 20:51:26',3,1,'早稻',1,'张',1,NULL,'2013-06-03 00:00:00',0),(3,'2013-08-28 03:04:15',2,'2013-08-28 03:03:54','测试',2,2,'2013-08-28 03:03:54',2,3,'测试',1,'hans',3,NULL,'2013-08-07 00:00:00',0),(4,'2013-08-29 06:39:48',2,'2013-08-29 06:39:13','生产期8月-10月',2,2,'2013-08-29 06:39:13',2,8,'甜玉米',1,'王吉谭',3,NULL,'2013-08-29 00:00:00',0),(5,NULL,0,'2013-08-29 06:39:42','',2,0,'2013-08-29 06:39:42',2,9,'冬小麦',1,'王吉潭',6,NULL,'2013-08-30 00:00:00',0);
/*!40000 ALTER TABLE `t_grow_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grow_resource`
--

DROP TABLE IF EXISTS `t_grow_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_grow_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_grow_resource`
--

LOCK TABLES `t_grow_resource` WRITE;
/*!40000 ALTER TABLE `t_grow_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_grow_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_instock`
--

DROP TABLE IF EXISTS `t_manure_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_instock`
--

LOCK TABLES `t_manure_instock` WRITE;
/*!40000 ALTER TABLE `t_manure_instock` DISABLE KEYS */;
INSERT INTO `t_manure_instock` VALUES (1,NULL,0,'2013-06-06 20:53:11','',3,2,'2013-06-06 20:53:11',3,3,5,1,4,123.00,2,'','2013-06-10 00:00:00','2013-05-27 00:00:00',3,'',1,'吖',''),(2,NULL,0,'2013-08-27 13:39:16','',2,0,'2013-08-27 13:39:16',2,3,5,1,4,33.00,2,'s','2013-08-31 00:00:00','2013-08-27 00:00:00',2,'Te',0,'Tes','gg'),(3,NULL,0,'2013-08-29 06:15:10','',2,2,'2013-08-29 06:15:10',2,16,5,1,4,5000.00,18,'磷酸二氢钾','2013-11-29 00:00:00','2013-08-29 00:00:00',2,'北京',2,'中化化肥有限公司','塑料'),(4,NULL,0,'2013-08-29 06:16:17','',2,2,'2013-08-29 06:16:17',2,3,6,20,10,1000.00,2,'','2013-11-14 00:00:00','2013-08-21 00:00:00',2,'',3,'','');
/*!40000 ALTER TABLE `t_manure_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_outstock`
--

DROP TABLE IF EXISTS `t_manure_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_outstock`
--

LOCK TABLES `t_manure_outstock` WRITE;
/*!40000 ALTER TABLE `t_manure_outstock` DISABLE KEYS */;
INSERT INTO `t_manure_outstock` VALUES (1,'2013-08-29 06:23:10',2,'2013-08-29 06:23:01','',0,2,NULL,0,16,0,1,4,100.00,18,3,'2013-08-29 00:00:00',2,3,2),(2,NULL,0,'2013-08-29 06:23:31','',0,0,NULL,0,3,0,20,10,300.00,2,3,'2013-08-29 00:00:00',2,3,3);
/*!40000 ALTER TABLE `t_manure_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_resource`
--

DROP TABLE IF EXISTS `t_manure_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_resource`
--

LOCK TABLES `t_manure_resource` WRITE;
/*!40000 ALTER TABLE `t_manure_resource` DISABLE KEYS */;
INSERT INTO `t_manure_resource` VALUES (1,NULL,0,'2013-06-06 20:51:58','',3,0,'2013-08-29 06:12:44',2,'磷酸二氢钾','PM'),(2,NULL,0,'2013-06-06 20:52:33','',3,0,'2013-08-29 06:12:01',2,'40kg','GG'),(3,NULL,0,'2013-06-06 20:52:44','',3,0,'2013-08-29 06:11:16',2,'20130821','SCPH'),(4,NULL,0,'2013-06-06 20:52:49','',3,0,'2013-08-29 06:09:50',2,'中化化肥有限公司','SCS'),(5,NULL,0,'2013-06-06 20:52:55','',3,0,'2013-08-29 06:13:17',2,'磷肥','ZL'),(6,NULL,0,'2013-08-29 06:09:12','',2,0,'2013-08-29 06:13:24',2,'氮肥','ZL'),(7,NULL,0,'2013-08-29 06:09:25','',2,0,'2013-08-29 06:13:30',2,'钾肥','ZL'),(8,NULL,0,'2013-08-29 06:09:36','',2,0,'2013-08-29 06:13:39',2,'矿物质','ZL'),(9,NULL,0,'2013-08-29 06:10:20','',2,0,'2013-08-29 06:10:20',2,'湖北宜化集团有限责任公司 ','SCS'),(10,NULL,0,'2013-08-29 06:10:29','',2,0,'2013-08-29 06:10:29',2,'山东鲁北企业集团总公司','SCS'),(11,NULL,0,'2013-08-29 06:10:38','',2,0,'2013-08-29 06:10:38',2,'云南煤化工集团有限公司','SCS'),(12,NULL,0,'2013-08-29 06:10:50','',2,0,'2013-08-29 06:10:50',2,'青海盐湖工业集团股份有限公司','SCS'),(13,NULL,0,'2013-08-29 06:10:52','',2,0,'2013-08-29 06:10:52',2,'青海盐湖工业集团股份有限公司','SCS'),(14,NULL,0,'2013-08-29 06:11:26','',2,0,'2013-08-29 06:11:26',2,'20130625','SCPH'),(15,NULL,0,'2013-08-29 06:11:34','',2,0,'2013-08-29 06:11:39',2,'20130518','SCPH'),(16,NULL,0,'2013-08-29 06:11:45','',2,0,'2013-08-29 06:11:45',2,'20130829','SCPH'),(17,NULL,0,'2013-08-29 06:12:08','',2,0,'2013-08-29 06:12:08',2,'2kg','GG'),(18,NULL,0,'2013-08-29 06:12:14','',2,0,'2013-08-29 06:12:14',2,'50kg','GG'),(19,NULL,0,'2013-08-29 06:12:22','',2,0,'2013-08-29 06:12:22',2,'10kg','GG'),(20,NULL,0,'2013-08-29 06:12:53','',2,0,'2013-08-29 06:12:53',2,'二铵','PM'),(21,NULL,0,'2013-08-29 06:12:58','',2,0,'2013-08-29 06:12:58',2,'磷肥','PM'),(22,NULL,0,'2013-08-29 06:13:07','',2,0,'2013-08-29 06:13:07',2,'叶面肥','PM');
/*!40000 ALTER TABLE `t_manure_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_manure_stock`
--

DROP TABLE IF EXISTS `t_manure_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_manure_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_manure_stock`
--

LOCK TABLES `t_manure_stock` WRITE;
/*!40000 ALTER TABLE `t_manure_stock` DISABLE KEYS */;
INSERT INTO `t_manure_stock` VALUES (1,NULL,0,'2013-06-06 20:53:14',NULL,0,0,NULL,0,3,0,1,4,123.00,2),(2,NULL,0,'2013-08-29 06:15:31',NULL,0,0,NULL,0,16,0,1,4,4900.00,18),(3,NULL,0,'2013-08-29 06:17:09',NULL,0,0,NULL,0,3,0,20,10,700.00,2);
/*!40000 ALTER TABLE `t_manure_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_instock`
--

DROP TABLE IF EXISTS `t_medicine_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_instock`
--

LOCK TABLES `t_medicine_instock` WRITE;
/*!40000 ALTER TABLE `t_medicine_instock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_outstock`
--

DROP TABLE IF EXISTS `t_medicine_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_outstock`
--

LOCK TABLES `t_medicine_outstock` WRITE;
/*!40000 ALTER TABLE `t_medicine_outstock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_resource`
--

DROP TABLE IF EXISTS `t_medicine_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_resource`
--

LOCK TABLES `t_medicine_resource` WRITE;
/*!40000 ALTER TABLE `t_medicine_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_medicine_stock`
--

DROP TABLE IF EXISTS `t_medicine_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_medicine_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_medicine_stock`
--

LOCK TABLES `t_medicine_stock` WRITE;
/*!40000 ALTER TABLE `t_medicine_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_medicine_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_farm`
--

DROP TABLE IF EXISTS `t_nurture_farm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_farm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `activitydate` datetime DEFAULT NULL,
  `cell_id` int(11) DEFAULT '0',
  `content` varchar(255) DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `persons` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `scale` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_farm`
--

LOCK TABLES `t_nurture_farm` WRITE;
/*!40000 ALTER TABLE `t_nurture_farm` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_farm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_harvest`
--

DROP TABLE IF EXISTS `t_nurture_harvest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_harvest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `method` varchar(60) DEFAULT NULL,
  `operatedate` datetime DEFAULT NULL,
  `product` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `respmanager` varchar(60) DEFAULT NULL,
  `scale` decimal(10,2) DEFAULT '0.00',
  `storage` varchar(60) DEFAULT NULL,
  `storemanager` varchar(60) DEFAULT NULL,
  `yield` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_harvest`
--

LOCK TABLES `t_nurture_harvest` WRITE;
/*!40000 ALTER TABLE `t_nurture_harvest` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_harvest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_irrigate`
--

DROP TABLE IF EXISTS `t_nurture_irrigate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_irrigate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `cell_id` int(11) DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `manager` varchar(60) DEFAULT NULL,
  `quantum` decimal(10,2) DEFAULT '0.00',
  `register_id` int(11) DEFAULT '0',
  `way` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_irrigate`
--

LOCK TABLES `t_nurture_irrigate` WRITE;
/*!40000 ALTER TABLE `t_nurture_irrigate` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_irrigate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_manure`
--

DROP TABLE IF EXISTS `t_nurture_manure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_manure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_manure`
--

LOCK TABLES `t_nurture_manure` WRITE;
/*!40000 ALTER TABLE `t_nurture_manure` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_manure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_pesticide`
--

DROP TABLE IF EXISTS `t_nurture_pesticide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_pesticide` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `isolation` decimal(10,2) DEFAULT '0.00',
  `machinecate` int(11) DEFAULT NULL,
  `method` int(11) DEFAULT NULL,
  `name_id` int(11) DEFAULT '0',
  `reason` varchar(100) DEFAULT NULL,
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  `tech` varchar(60) DEFAULT NULL,
  `usedate` datetime DEFAULT NULL,
  `useperson` varchar(60) DEFAULT NULL,
  `useqty` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_pesticide`
--

LOCK TABLES `t_nurture_pesticide` WRITE;
/*!40000 ALTER TABLE `t_nurture_pesticide` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_pesticide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_nurture_register`
--

DROP TABLE IF EXISTS `t_nurture_register`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_nurture_register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `description` varchar(100) DEFAULT NULL,
  `nurturestatus` int(11) DEFAULT '0',
  `person` varchar(36) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qrcode` longblob,
  `regdate` datetime DEFAULT NULL,
  `reguser_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_nurture_register`
--

LOCK TABLES `t_nurture_register` WRITE;
/*!40000 ALTER TABLE `t_nurture_register` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_nurture_register` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_instock`
--

DROP TABLE IF EXISTS `t_pesticide_instock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_instock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `element` varchar(60) DEFAULT NULL,
  `expirydate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `inuser_id` int(11) DEFAULT '0',
  `location` varchar(60) DEFAULT NULL,
  `stock_id` int(11) DEFAULT '0',
  `vendor` varchar(60) DEFAULT NULL,
  `wrap` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_instock`
--

LOCK TABLES `t_pesticide_instock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_instock` DISABLE KEYS */;
INSERT INTO `t_pesticide_instock` VALUES (1,NULL,0,'2013-08-29 06:54:00','',2,2,'2013-08-29 06:54:00',2,7,1,12,5,500.00,9,'','2014-08-29 00:00:00','2013-08-29 00:00:00',2,'',1,'',''),(2,NULL,0,'2013-08-29 06:54:37','',2,2,'2013-08-29 06:54:37',2,8,3,13,5,200.00,9,'','2013-09-26 00:00:00','2013-08-29 00:00:00',2,'',2,'',''),(3,NULL,0,'2013-08-29 06:55:13','',2,0,'2013-08-29 06:55:13',2,7,4,14,6,50.00,11,'','2013-08-30 00:00:00','2013-08-23 00:00:00',2,'',0,'','');
/*!40000 ALTER TABLE `t_pesticide_instock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_outstock`
--

DROP TABLE IF EXISTS `t_pesticide_outstock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_outstock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  `cell_id` int(11) DEFAULT '0',
  `outdate` datetime DEFAULT NULL,
  `outuser_id` int(11) DEFAULT '0',
  `register_id` int(11) DEFAULT '0',
  `stock_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_outstock`
--

LOCK TABLES `t_pesticide_outstock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_outstock` DISABLE KEYS */;
INSERT INTO `t_pesticide_outstock` VALUES (1,'2013-08-29 06:56:01',2,'2013-08-29 06:55:43','',0,2,NULL,0,7,0,12,5,50.00,9,3,'2013-08-30 00:00:00',2,3,1),(2,NULL,0,'2013-08-29 06:55:58','',0,0,NULL,0,8,0,13,5,100.00,9,3,'2013-08-31 00:00:00',2,3,2);
/*!40000 ALTER TABLE `t_pesticide_outstock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_resource`
--

DROP TABLE IF EXISTS `t_pesticide_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_resource` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `name` varchar(60) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_resource`
--

LOCK TABLES `t_pesticide_resource` WRITE;
/*!40000 ALTER TABLE `t_pesticide_resource` DISABLE KEYS */;
INSERT INTO `t_pesticide_resource` VALUES (1,NULL,0,'2013-08-29 06:47:24','',2,0,'2013-08-29 06:47:24',2,'杀虫剂','ZL'),(2,NULL,0,'2013-08-29 06:47:33','',2,0,'2013-08-29 06:47:33',2,'除草剂','ZL'),(3,NULL,0,'2013-08-29 06:47:47','',2,0,'2013-08-29 06:47:47',2,'杀菌剂','ZL'),(4,NULL,0,'2013-08-29 06:48:03','',2,0,'2013-08-29 06:48:03',2,'营养调和剂','ZL'),(5,'2013-08-29 06:48:44',2,'2013-08-29 06:48:25','',2,2,'2013-08-29 06:48:25',2,'中化生物农药有限公司','SCS'),(6,NULL,0,'2013-08-29 06:48:41','',2,0,'2013-08-29 06:48:41',2,'江西生物农药有限公司','SCS'),(7,'2013-08-29 06:49:06',2,'2013-08-29 06:48:55','',2,2,'2013-08-29 06:48:55',2,'20130821','SCPH'),(8,NULL,0,'2013-08-29 06:49:02','',2,0,'2013-08-29 06:49:02',2,'20130829','SCPH'),(9,'2013-08-29 06:49:29',2,'2013-08-29 06:49:15','',2,2,'2013-08-29 06:49:15',2,'10kg','GG'),(10,'2013-08-29 06:49:31',2,'2013-08-29 06:49:21','',2,2,'2013-08-29 06:49:21',2,'2kg','GG'),(11,NULL,0,'2013-08-29 06:49:26','',2,0,'2013-08-29 06:49:26',2,'500g','GG'),(12,'2013-08-29 06:50:19',2,'2013-08-29 06:49:47','',2,2,'2013-08-29 06:49:47',2,'杀虫双','PM'),(13,'2013-08-29 06:50:23',2,'2013-08-29 06:49:59','',2,2,'2013-08-29 06:49:59',2,'辛硫磷','PM'),(14,NULL,0,'2013-08-29 06:50:08','',2,0,'2013-08-29 06:50:08',2,'石硫合剂','PM'),(15,NULL,0,'2013-08-29 06:50:15','',2,0,'2013-08-29 06:50:15',2,'叶面宝','PM'),(16,NULL,0,'2013-08-29 06:50:50','',2,0,'2013-08-29 06:50:50',2,'甲基硫菌灵','PM'),(17,NULL,0,'2013-08-29 06:51:04','',2,0,'2013-08-29 06:51:04',2,'宝成','PM'),(18,NULL,0,'2013-08-29 06:51:52','',2,0,'2013-08-29 06:51:52',2,'银法利','PM'),(19,NULL,0,'2013-08-29 06:52:06','',2,0,'2013-08-29 06:52:06',2,'氟吡菌胺','PM'),(20,NULL,0,'2013-08-29 06:52:18','',2,0,'2013-08-29 06:52:18',2,'高效氯氟氰菊酯','PM'),(21,NULL,0,'2013-08-29 06:52:35','',2,0,'2013-08-29 06:52:35',2,'噻虫嗪','PM');
/*!40000 ALTER TABLE `t_pesticide_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_pesticide_stock`
--

DROP TABLE IF EXISTS `t_pesticide_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_pesticide_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `name_id` int(11) DEFAULT '0',
  `producer_id` int(11) DEFAULT '0',
  `quantity` decimal(10,2) DEFAULT '0.00',
  `spec_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_pesticide_stock`
--

LOCK TABLES `t_pesticide_stock` WRITE;
/*!40000 ALTER TABLE `t_pesticide_stock` DISABLE KEYS */;
INSERT INTO `t_pesticide_stock` VALUES (1,NULL,0,'2013-08-29 06:54:06',NULL,0,0,NULL,0,7,0,12,5,450.00,9),(2,NULL,0,'2013-08-29 06:54:41',NULL,0,0,NULL,0,8,0,13,5,100.00,9);
/*!40000 ALTER TABLE `t_pesticide_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_production_cell`
--

DROP TABLE IF EXISTS `t_production_cell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_production_cell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `area` decimal(10,2) DEFAULT '0.00',
  `builddate` datetime DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `usestatus` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_production_cell`
--

LOCK TABLES `t_production_cell` WRITE;
/*!40000 ALTER TABLE `t_production_cell` DISABLE KEYS */;
INSERT INTO `t_production_cell` VALUES (1,'2013-06-06 20:40:08',3,'2013-06-06 20:39:08',NULL,3,2,'2013-06-06 20:51:26',3,1001.00,'2013-06-02 00:00:00','单元A','东方',1),(2,'2013-08-29 06:37:18',2,'2013-06-06 20:39:25',NULL,3,2,'2013-06-06 20:39:25',3,1002.00,'2013-06-02 00:00:00','单元B','南方',0),(3,'2013-06-06 20:40:14',3,'2013-06-06 20:39:42',NULL,3,2,'2013-08-29 07:01:23',2,1003.00,'2013-05-26 00:00:00','单元C','西方',0),(4,'2013-08-29 06:37:21',2,'2013-06-06 20:39:56',NULL,3,2,'2013-06-06 20:39:56',3,1004.00,'2013-05-30 00:00:00','单元D','北方',0),(5,'2013-08-27 13:37:21',2,'2013-08-27 13:37:16',NULL,2,2,'2013-08-27 13:38:18',2,123.00,'2013-08-07 00:00:00','TEST1','test1',0),(6,'2013-08-29 01:03:59',2,'2013-08-29 01:03:23',NULL,2,2,'2013-08-29 01:03:53',2,1000.00,'2013-07-28 00:00:00','单元E','西南1',0),(7,NULL,0,'2013-08-29 06:32:51',NULL,2,0,'2013-08-29 06:32:51',2,500.00,'2013-08-29 00:00:00','CQC-A','南四环西路1号楼',0),(8,'2013-08-29 06:37:15',2,'2013-08-29 06:33:16',NULL,2,2,'2013-08-29 06:39:13',2,500.00,'2013-08-29 00:00:00','CQC-B','2号楼',1),(9,'2013-08-29 06:37:11',2,'2013-08-29 06:33:40',NULL,2,2,'2013-08-29 06:39:42',2,500.00,'2013-08-29 00:00:00','CQC-C','3号楼',1),(10,'2013-08-29 06:37:08',2,'2013-08-29 06:34:13',NULL,2,2,'2013-08-29 06:34:13',2,500.00,'2013-08-30 00:00:00','CQC-D','4号楼',0);
/*!40000 ALTER TABLE `t_production_cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_sale`
--

DROP TABLE IF EXISTS `t_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `contact` varchar(50) DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `partner` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `saledate` datetime DEFAULT NULL,
  `spec` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_sale`
--

LOCK TABLES `t_sale` WRITE;
/*!40000 ALTER TABLE `t_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_transport`
--

DROP TABLE IF EXISTS `t_transport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `batch` int(11) DEFAULT '0',
  `contact` varchar(50) DEFAULT NULL,
  `level` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `partner` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT '0.00',
  `transportdate` datetime DEFAULT NULL,
  `spec` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_transport`
--

LOCK TABLES `t_transport` WRITE;
/*!40000 ALTER TABLE `t_transport` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_transport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adate` datetime DEFAULT NULL,
  `auser_id` int(11) DEFAULT '0',
  `cdate` datetime DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `cuser_id` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `udate` datetime DEFAULT NULL,
  `uuser_id` int(11) DEFAULT '0',
  `pass_word` varchar(20) DEFAULT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` VALUES (1,NULL,0,NULL,NULL,0,0,NULL,0,'admin','admin','公司管理员');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-17 11:13:00
